#include<iostream>
#include<vector>
using namespace std;
int main(){
    vector <char> vec={'a','b','c','d','e'};
    cout << "size = " << vec.size() << endl;//name.size() gives the length of the array
    return 0;
}